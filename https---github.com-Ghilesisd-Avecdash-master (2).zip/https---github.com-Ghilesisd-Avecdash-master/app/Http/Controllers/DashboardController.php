<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;
use App\Models\Ticket;

use Illuminate\Support\Facades\Auth;

use App\Models\Types_incident;
use App\Models\Categorie;
use App\Models\Impact;
use App\Models\Priorite;
use App\Models\Statut;
use App\Models\Urgence;
use App\Models\User;
use App\Models\Etat;
use PhpParser\Node\Stmt\Foreach_;
use App\Models\Tracage;
use App\Models\Structure;

class DashboardController extends Controller
{
  public function index()
  {
    $role = Auth::user()->role;
    $name = Auth::user()->name;
    $auth_struct = Auth::user()->structure_id;
    $user = User::all();
    $categories = Categorie::all();
    $ticket = Ticket::all();
    $types_incidents = Types_incident::all();
    $tracage = Tracage::all();
    $urgence = Urgence::all();
    $statut = Statut::all();
    $priorite = Priorite::all();
    $impact = Impact::all();
    $etat = Etat::all();
    $structure = Structure::all();


    $nbr_ticket = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')

      ->where('users.structure_id', $auth_struct)
      ->count();

    $nbr_resolu = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('etats_id', '1')
      ->count();
    $nbr_cour = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('etats_id', '2')
      ->count();
    $nbr_fer = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('statuts_id', '7')
      ->count();


    $prob = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '1')
      ->count();

    $inc = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '3')
      ->count();

    $service = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '2')
      ->count();
    ////////////////:::::::::::::::::::::::::::::::::::::bar resolue
    $prob0 = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '1')
      ->where('statuts_id', '5')
      ->count();

    $inc0 = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '3')
      ->where('statuts_id', '5')
      ->count();

    $service0 = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '2')
      ->where('statuts_id', '5')
      ->count();
    /////////////////////bar en cour
    $probe = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '1')
      ->where('statuts_id', '4')
      ->count();

    $ince = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '3')
      ->where('statuts_id', '4')
      ->count();

    $servicee = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '2')
      ->where('statuts_id', '4')
      ->count();
    ////////////////////::affecter

    $probb = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '1')
      ->where('statuts_id', '3')
      ->count();

    $incb = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '3')
      ->where('statuts_id', '3')
      ->count();

    $serviceb = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('typess_id', '2')
      ->where('statuts_id', '3')
      ->count();

    /////////////////::::donouhts
    $tel0 = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('id_categos', '3')
      ->count();

    $hard0 = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('id_categos', '1')
      ->count();

    $soft0 = Ticket::join('users', 'tickets.id_utilisateur', '=', 'users.id')
      ->where('users.structure_id', $auth_struct)
      ->where('id_categos', '2')
      ->count();
    /////////////////////////////////////////////////////////////////////////////////////////////::Technique
    $v = 0;
    foreach ($user as $item) {
      if ($item->role == 3) {
        foreach ($ticket as $item1) {
          if ($item->id == $item1->id_technicien) { {
              $v = $v + 1;
            }
          }
        }
      }
    }
    $s = 0;
    foreach ($user as $item) {
      if ($item->role == 3) {
        foreach ($tracage as $item1) {
          if ($item->id == $item1->id_technicien) { {
              $s = $s + 1;
            }
          }
        }
      }
    }
    $sup5 = Ticket::all()->count();
    $nbr5_resolu = Ticket::where('statuts_id', '3')->count();
    $nbr_tech = User::where('role', '3')->count();
    $nbr_non = Ticket::where('statuts_id', '1')->count();
    $nbr1 = Ticket::where('statuts_id', '6')
      ->where('typess_id', '2')->count();
    $nbr2 = Ticket::where('statuts_id', '6')
      ->where('typess_id', '1')->count();
    $nbr3 = Ticket::where('statuts_id', '6')
      ->where('typess_id', '3')->count();
    ///////barchar tech
    /////totale
    $prot = Ticket::where('typess_id', '1')->count();
    $inct = Ticket::where('typess_id', '3')->count();
    $servicet = Ticket::where('typess_id', '2')->count();
    /////////:::///////////////::resolu
    $servicer = Ticket::where('typess_id', '2')
      ->where('statuts_id', '5')
      ->count();
    $incr = Ticket::where('typess_id', '3')
      ->where('statuts_id', '5')
      ->count();
    $pror = Ticket::where('typess_id', '1')
      ->where('statuts_id', '5')
      ->count();
    ///enn cour
    $servicec = Ticket::where('typess_id', '2')
      ->where('statuts_id', '4')
      ->count();
    $incc = Ticket::where('typess_id', '3')
      ->where('statuts_id', '4')
      ->count();
    $proc = Ticket::where('typess_id', '1')
      ->where('statuts_id', '4')
      ->count();
    ///affecter
    $servicea = Ticket::where('typess_id', '2')
      ->where('statuts_id', '3')
      ->count();
    $inca = Ticket::where('typess_id', '3')
      ->where('statuts_id', '3')
      ->count();
    $proa = Ticket::where('typess_id', '1')
      ->where('statuts_id', '3')
      ->count();
    //fermer
    $servicef = Ticket::where('typess_id', '2')
      ->where('statuts_id', '6')
      ->count();
    $incf = Ticket::where('typess_id', '3')
      ->where('statuts_id', '6')
      ->count();
    $prof = Ticket::where('typess_id', '1')
      ->where('statuts_id', '6')
      ->count();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    return view('dashboardpage', compact(
      'ticket',
      'categories',
      'types_incidents',
      'structure',
      'sup5',
      'nbr5_resolu',
      'nbr_tech',
      'nbr_non',
      'nbr1',
      'nbr2',
      'nbr3',
      'prot',
      'inct',
      'servicet',
      'pror',
      'incr',
      'servicer',
      'proa',
      'inca',
      'servicea',
      'prof',
      'incf',
      'servicef',
      'servicec',
      'proc',
      'incc',
      'nbr_ticket',
      'nbr_resolu',
      'nbr_cour',
      'nbr_fer',
      'prob',
      'inc',
      'service',
      'prob0',
      'inc0',
      'service0',
      'probe',
      'ince',
      'servicee',
      'probb',
      'incb',
      'serviceb',
      'tel0',
      'hard0',
      'soft0',
      'urgence',
      'statut',
      'priorite',
      'impact',
      'role',
      'name',
      'etat',
      'user',
      'v',
      'tracage',
      's',
      'auth_struct'
    ));
  }
}
