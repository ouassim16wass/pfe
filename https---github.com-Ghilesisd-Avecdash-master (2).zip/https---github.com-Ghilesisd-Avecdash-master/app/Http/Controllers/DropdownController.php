<?php

namespace App\Http\Controllers;

use App\Models\Subcatego;
use App\Models\Catego;
use Illuminate\Http\Request;

class DropdownController extends Controller
{
    /**
     * load dropdowns blade
     * @param NA
     * @return view
     */
    public function index()
    {
        $categos = Catego::all();
        return view('dropdowns', compact('categos'));
    }

    /**
     * Get all frameworks based on language
     * @param request
     * @return response
     */
    public function getFrameworks(Request $request)
    {
        if ($request->languageId) {
            $frameworks = Subcatego::where('sub_id', $request->languageId)->get();
            if ($frameworks) {
                return response()->json(['status' => 'success', 'data' => $frameworks], 200);
            }
            return response()->json(['status' => 'failed', 'message' => 'No frameworks found'], 404);
        }
        return response()->json(['status' => 'failed', 'message' => 'Please select language'], 500);
    }
}
