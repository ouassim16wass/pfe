<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use Illuminate\Http\Request;
use App\Models\Types_incident;
use App\Models\Categorie;
use App\Models\Impact;
use App\Models\Priorite;
use App\Models\Statut;
use App\Models\Urgence;
use App\Models\User;
use App\Models\Etat;
use App\Models\Tracage;

use App\Models\Catego;
use App\Models\Subcatego;




use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\getClientOriginalName;

class TicketController extends Controller
{


  public function __construct()
  {
    $this->middleware('auth');
  }



  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request)
  {
    $role = Auth::user()->role;

    $name = Auth::user()->name;
    $auth_struct = Auth::user()->structure_id;
    $categories = Categorie::all();
    $ticket = Ticket::all();
    $types_incidents = Types_incident::all();

    $urgence = Urgence::all();
    $statut = Statut::all();
    $priorite = Priorite::all();
    $impact = Impact::all();
    $etat = Etat::all();
    $user = User::all();
    $catego = Catego::all();



    return view('ticket.index', compact('auth_struct', 'catego', 'ticket', 'user', 'categories', 'types_incidents', 'urgence', 'statut', 'priorite', 'impact', 'role', 'name', 'etat'));


    // $tickets = Ticket::all()->toArray();
    //  return array_reverse($tickets);

  }



  public function getFrameworks(Request $request)
  {
    if ($request->languageId) {
      $frameworks = Subcatego::where('sub_id', $request->languageId)->get();
      if ($frameworks) {
        return response()->json(['status' => 'success', 'data' => $frameworks], 200);
      }
      return response()->json(['status' => 'failed', 'message' => 'No frameworks found'], 404);
    }
    return response()->json(['status' => 'failed', 'message' => 'Please select language'], 500);
  }

  public function archive()
  {






    $role = Auth::user()->role;

    $name = Auth::user()->name;
    $user = User::all();
    $categories = Categorie::all();
    $ticket = Ticket::all();

    $types_incidents = Types_incident::all();

    $urgence = Urgence::all();
    $statut = Statut::all();
    $priorite = Priorite::all();
    $impact = Impact::all();
    $etat = Etat::all();
    $auth_struct = Auth::user()->structure_id;





    return view('ticket.archive', compact('auth_struct', 'ticket', 'user', 'categories', 'types_incidents', 'urgence', 'statut', 'priorite', 'impact', 'role', 'name', 'etat'));


    // $tickets = Ticket::all()->toArray();
    //  return array_reverse($tickets);

  }
  public function getCategories()
  {
    $data = Categorie::get();
    return response()->json($data);
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    $types_incidents = Types_incident::all();
    $categorie = Categorie::all();

    $urgence = Urgence::all();
    $statut = Statut::all();
    $priorite = Priorite::all();
    $impact = Impact::all();
    $role = Auth::user()->role;
    $etat = Etat::all();
    $name = Auth::user()->name;
    $catego = Catego::all();
    $sub_catego = Subcatego::all();











    return view('ticket.create', compact('types_incidents', 'catego', 'sub_catego', 'categorie', 'urgence', 'statut', 'priorite', 'impact', 'role', 'name', 'etat'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */

  public function downloadincident(Ticket $ticket)
  {

    //return view('testdown');

    return Storage::download($ticket->jointe_incident);
  }

  public function downloadsolution(Tracage $tracage)
  {

    //return view('testdown');

    return Storage::download($tracage->t_solution);
  }


  public function store(Request $request)
  {




    if ($request->jointe_incident != null) {
      $j_incident = Storage::disk('local')->put('newup', $request->jointe_incident);
    }






    if ($request->jointe_incident != null) {
      $ticket = Ticket::create([
        'Titre_ticket' => $request->Titre_ticket,
        'jointe_incident' => $j_incident,
        'date_incident' => $request->date_incident,
        'id_utilisateur' => $request->id_utilisateur,
        'description' => $request->description,
        'impacts_id' => $request->impacts_id,
        'statuts_id' => $request->statuts_id,
        'priorites_id' => $request->priorites_id,
        'urgences_id' => $request->urgences_id,
        'categorie_id' => $request->categorie_id,
        'etats_id' => $request->etats_id,
        'typess_id' => $request->typess_id,
        'id_categos' => $request->id_categos,
        'id_sub_categos' => $request->id_sub_categos,


      ]);
    }
    if ($request->jointe_incident == null) {

      $ticket = Ticket::create([
        'Titre_ticket' => $request->Titre_ticket,

        'date_incident' => $request->date_incident,
        'id_utilisateur' => $request->id_utilisateur,
        'description' => $request->description,
        'impacts_id' => $request->impacts_id,
        'statuts_id' => $request->statuts_id,
        'priorites_id' => $request->priorites_id,
        'urgences_id' => $request->urgences_id,
        'categorie_id' => $request->categorie_id,
        'etats_id' => $request->etats_id,
        'typess_id' => $request->typess_id,
        'id_categos' => $request->id_categos,
        'id_sub_categos' => $request->id_sub_categos,


      ]);
    }





    return redirect('tickets')->with('success', 'added successfully');
  }



  /**
   * Display the specified resource.
   *
   * @param  \App\Models\Ticket  $ticket
   * @return \Illuminate\Http\Response
   */


  public function show(Ticket $ticket)
  {


    return Storage::download($ticket->jointe_incident);


    return Storage::download($ticket->jointe_solution);


    return view('ticket.show', compact('ticket'));
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Models\Ticket  $ticket
   * @return \Illuminate\Http\Response
   */
  public function edit(Ticket $ticket)
  {
    $types_incidents = Types_incident::all();
    $categorie = Categorie::all();
    $urgence = Urgence::all();
    $statut = Statut::all();
    $priorite = Priorite::all();
    $impact = Impact::all();
    $role = Auth::user()->role;
    $id = Auth::user()->id;
    $etat = Etat::all();
    $name = Auth::user()->name;
    $user = User::all();
    $flag = 0;
    $tracage = Tracage::all();
    $catego = Catego::all();
    $sub_catego = Subcatego::all();
    $auth_struct = Auth::user()->structure_id;



    return view('ticket.edit', compact('auth_struct', 'sub_catego', 'catego', 'ticket', 'id', 'tracage', 'flag', 'types_incidents', 'categorie', 'urgence', 'statut', 'priorite', 'impact', 'role', 'name', 'etat', 'user'));
  }




  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Models\Ticket  $ticket
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, Ticket $ticket, Tracage $tracage)
  {

    if ($request->t_solution != null) {
      $j_solution = Storage::disk('local')->put('solu', $request->t_solution);
    }

    $id = Auth::user()->id;
    $ticket->update([
      'Titre_ticket' => $request->Titre_ticket,
      //  'jointe_incident'=>$j_incident,
      // 'jointe_solution'=>$j_rapport,
      //   'id_utilisateur'=> $request->id_utilisateur,
      //   'description'=> $request->description,
      //    'impacts_id'=> $request->impacts_id,
      'statuts_id' => $request->statuts_id,
        'priorites_id'=> $request->priorites_id,
      //  'urgences_id'=> $request->urgences_id,
      //   'categorie_id'=> $request->categorie_id,
      'etats_id' => $request->etats_id,
         'typess_id'=>$request->typess_id,
      'id_technicien' => $request->id_technicien,


    ]);










    /*
      if ($request->jointe_solution !=null){
     $j_rapport= Storage::disk('local')->put('nouvelle', $request->jointe_solution);
   }

        //$path = Storage::path($request->jointe_solution);
        if ($ticket->jointe_solution){
        
        
          
        $ticket->update([
           'Titre_ticket'=>$request->Titre_ticket,
          //  'jointe_incident'=>$j_incident,
         // 'jointe_solution'=>$j_rapport,
         //   'id_utilisateur'=> $request->id_utilisateur,
         //   'description'=> $request->description,
        //    'impacts_id'=> $request->impacts_id,
            'statuts_id'=> $request->statuts_id,
          //  'priorites_id'=> $request->priorites_id,
          //  'urgences_id'=> $request->urgences_id,
         //   'categorie_id'=> $request->categorie_id,
           'etats_id'=> $request->etats_id,
         //   'typess_id'=>$request->typess_id,
         'id_technicien'=>$request->id_technicien,
      

        ]);
    }

        else if ( $request->jointe_solution && $ticket->jointe_solution==null ){
            $ticket->update([
                'Titre_ticket'=>$request->Titre_ticket,
               //  'jointe_incident'=>$j_incident,
               'jointe_solution'=>$j_rapport,
              //   'id_utilisateur'=> $request->id_utilisateur,
              //   'description'=> $request->description,
             //    'impacts_id'=> $request->impacts_id,
                 'statuts_id'=> $request->statuts_id,
               //  'priorites_id'=> $request->priorites_id,
               //  'urgences_id'=> $request->urgences_id,
              //   'categorie_id'=> $request->categorie_id,
                'etats_id'=> $request->etats_id,
              //   'typess_id'=>$request->typess_id,
              'id_technicien'=>$request->id_technicien,
     
             ]);
        }

        else if (  $ticket->jointe_solution==null ){
          $ticket->update([
              'Titre_ticket'=>$request->Titre_ticket,
             //  'jointe_incident'=>$j_incident,
            // 'jointe_solution'=>$j_rapport,
            //   'id_utilisateur'=> $request->id_utilisateur,
            //   'description'=> $request->description,
           //    'impacts_id'=> $request->impacts_id,
               'statuts_id'=> $request->statuts_id,
             //  'priorites_id'=> $request->priorites_id,
             //  'urgences_id'=> $request->urgences_id,
            //   'categorie_id'=> $request->categorie_id,
              'etats_id'=> $request->etats_id,
            //   'typess_id'=>$request->typess_id,
            'id_technicien'=>$request->id_technicien,
   
           ]);
      }*/

    if ($request->t_solution == null && $request->t_commentaire == null) {
    }
    if ($request->t_solution == null && $request->t_commentaire != null) {
      $trace = Tracage::create([
        'id_ticket' => $ticket->id,
        'id_technicien' => $id,


        't_commentaire' => $request->t_commentaire,


      ]);
    }

    if ($request->t_solution != null && $request->t_commentaire == null) {
      $trace = Tracage::create([
        'id_ticket' => $ticket->id,
        'id_technicien' => $id,

        't_solution' => $j_solution,



      ]);
    }

    if ($request->t_solution != null && $request->t_commentaire != null) {
      $trace = Tracage::create([
        'id_ticket' => $ticket->id,
        'id_technicien' => $id,

        't_solution' => $j_solution,
        't_commentaire' => $request->t_commentaire,


      ]);
    }










    return redirect()->route('tickets.index')
      ->with('success', 'ticket updated successflly');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Models\Ticket  $ticket
   * @return \Illuminate\Http\Response
   */
  public function destroy(Ticket $ticket)
  {
    //
  }
}
