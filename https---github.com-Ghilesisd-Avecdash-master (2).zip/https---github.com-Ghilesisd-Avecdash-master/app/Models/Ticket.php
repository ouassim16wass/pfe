<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    protected $fillable = [
        'Titre_ticket', 'id_categos', 'id_sub_categos', 'description', 'impacts_id', 'etat', "statuts_id", "priorites_id", "urgences_id",
        "categorie_id", 'id_utilisateur', "date_incident",'etats_id', 'jointe_incident', 'typess_id', 'jointe_solution', 'id_technicien', 's_categorie'
    ];
}
