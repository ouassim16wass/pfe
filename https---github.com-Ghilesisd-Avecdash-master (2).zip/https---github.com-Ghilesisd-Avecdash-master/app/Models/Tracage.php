<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tracage extends Model
{
    protected $fillable = ['id_ticket','id_technicien','t_commentaire','t_solution'];
}

