@extends('ticket.layout');

@section('content')

<style>
        .jumbotron {
           margin-left: 250px!important;
             margin-top: 75px!important;
        }
    </style>








<div class="container ">


  
  <div class="jumbotron">
  

<h1> welcome to create page <h1>

    <h2>Créer un ticket</h2>

  
    
    <form action="{{route('tickets.store')}}" method='POST' class="col-md-6">
      
    @csrf
  
    <div class="form-group">
      <label for="inputtype">Type d'incidents</label>
 
     <select class="form-select form-select-sm" aria-label=".form-select-sm example" name="typess_id">
     
     
      @foreach($types_incidents as $item)
      
     
        
      <option value="1">{{ $item->nom_type_incident }}</option>
      @endforeach
     
     </select>
    </div>
  <div class="form-group">
    <label for="inputtype">Categorie d'incidents</label>
    <select class="form-select form-select-sm" aria-label=".form-select-sm example" name="categorie_id"> 
      @foreach($categorie as $item)  
      <option value="1">{{ $item->nom_categorie }}</option>
      @endforeach
     
    </select>
  </div>

  <div class="form-group ">
      <label for="inputetat">Titre</label>
      <input type="text" class="form-control" id="inputetat" name="titre_ticket">
  </div>
  <div class="form-group ">
    <label for="inputtype">Impact d'incidents</label>
    <select class="form-select form-select-sm" aria-label=".form-select-sm example" name="impact_id">
     
     
     @foreach($impact as $item)
     
    
       
     <option value="1">{{ $item->type_impact }}</option>
     @endforeach
    
    </select>
 </div>

 <div class="form-group ">
    <label for="inputtype">Urgence d'incidents</label>
    <select class="form-select form-select-sm" aria-label=".form-select-sm example" name="urgence_id">
     
     
     @foreach($urgence as $item)
     
    
       
     <option value="1">{{ $item->type_urgence }}</option>
     @endforeach
    
   </select>
 </div>
 <div class="form-group ">
    <label for="inputtype">Priorité d'incidents</label>
    <select class="form-select form-select-sm" aria-label=".form-select-sm example" name="priorite_id">
     
     
     @foreach($priorite as $item)
     
    
       
     <option value="1">{{ $item->type_priorite }}</option>
     @endforeach
    
   </select>
 </div>
 <div class="form-group ">
   <label for="inputtype">Statut de l'incident</label>
    <select class="form-select form-select-sm" aria-label=".form-select-sm example" name="statut_statut">
     
     
     @foreach($statut as $item)
     
    
       
     <option value="1">{{ $item->type_statut }}</option>
     @endforeach
    
   </select>
 </div>
  <div class="form-group">
    <label for="description">Description</label>
    <textarea class="form-control" id="inputdescription" rows="3" name="description"></textarea>
  </div>
  
   
    
  <!--  <div class="form-group col-md-2">
      <label for="inputetat">Etat</label>
      <input type="text" class="form-control" id="inputetat" name="etat">
    </div> 
      -->
  
  
  <button type="submit" class="btn btn-primary">Declarer l'incident</button>
  
  

</form>


  <!-- Content here -->

  </div>
 
  </div>
  <div id="app">
  <app></app> </div>



 


@endsection
