<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTracagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tracages', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('id_ticket')->unsigned()->index()->nullable();
        $table->foreign('id_ticket')->references('id')->on('tickets')->onDelete('cascade')->nullable();

        $table->bigInteger('id_technicien')->unsigned()->index()->nullable();
        $table->foreign('id_technicien')->references('id')->on('users')->onDelete('cascade')->nullable();


            $table->string('t_solution')->nullable();
            $table->string('t_commentaire')->nullable();


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tracages');
    }
}
