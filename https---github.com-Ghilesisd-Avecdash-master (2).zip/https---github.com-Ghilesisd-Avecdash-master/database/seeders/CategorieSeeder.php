<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Catego;
use App\Models\Subcatego;

class CategorieSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $dataArray = array(
            'Hardware' => [
                'Materiel'

            ],
            'Software' => [
                'Logiciel',
                'Windows'

            ],
            'Telecommunication' => [
                'DNS',
                'Server',
                'Reseau'

            ],

        );

        foreach ($dataArray as $language => $frameworks) {

            $language = Catego::create([
                'nom_categorie' => $language
            ]);

            if ($language) {
                foreach ($frameworks as $key => $framework) {
                    Subcatego::create([
                        'sub_id' => $language->id,
                        'subnom' => $framework
                    ]);
                }
            }
        }
    }
}
